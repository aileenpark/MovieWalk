package com.example.webtest;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ListAdapter extends BaseAdapter {

    private Context context;
    private List<Data> dataList;

    public ListAdapter(Context context, List<Data> dataList){
        this.context = context;
        this.dataList = dataList;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(context,R.layout.user,null);

        TextView ID = (TextView) v.findViewById(R.id.ID);
        TextView NAME = (TextView) v.findViewById(R.id.NAME);
        TextView TITLE = (TextView) v.findViewById(R.id.TITLE);
        TextView LATITUDE = (TextView) v.findViewById(R.id.LATITUDE);
        TextView LONGITUDE = (TextView) v.findViewById(R.id.LONGITUDE);
        TextView ADDRESS = (TextView) v.findViewById(R.id.ADDRESS);
        TextView IMAGE1= (TextView) v.findViewById(R.id.IMAGE1);
        TextView IMAGE2 = (TextView) v.findViewById(R.id.IMAGE2);
        TextView INFORMATION = (TextView) v.findViewById(R.id.INFORMATION);

        ID.setText(dataList.get(position).getMember_id());
        NAME.setText(dataList.get(position).getMember_name());
        TITLE.setText(dataList.get(position).getMember_title());
        LATITUDE.setText(dataList.get(position).getMember_latitude());
        LONGITUDE.setText(dataList.get(position).getMember_longitude());
        ADDRESS.setText(dataList.get(position).getMember_address());
        IMAGE1.setText(dataList.get(position).getMember_image1());
        IMAGE2.setText(dataList.get(position).getMember_image2());
        INFORMATION.setText(dataList.get(position).getMember_information());

        v.setTag(dataList.get(position).getMember_id());
        return v;
    }
}
